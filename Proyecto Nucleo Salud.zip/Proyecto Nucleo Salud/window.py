'''
Equipo 5

    Moscoso Cedillo Edmundo Enrique
    Ornelas Durán Natalia Alessandra
    Paez Medrano Kevin Randú
    Quistian Arreguín Victor Daniel
    Rentería Xochipa Moisés Alejandro
'''

import tkinter as tk
import connection as dataBase
from tkinter import messagebox, ttk
from PIL import ImageTk, Image

# Función para agregar un Empleado
def agregarEmpleado():
    global conexion

    def enviarPeticionBD():
        try:
            peticion = 'INSERT INTO public."EMPLEADO"("Nombre", "Dirección", "Teléfono", "Fecha_Nac", "Sexo", "Sueldo", "Turno", "Contraseña") VALUES (%s, %s, %s, %s, %s, %s, %s, %s);'
            valores = (nombre.get(), direccion.get(), telefono.get(), fechaNac.get(), sexo.get(), sueldo.get(), turno.get(), contrasena.get())
            conexion.execute(peticion, valores)
            conexion.connection.commit()
            messagebox.showinfo('Éxito', 'Empleado agregado correctamente.')
        except Exception as ex:
            messagebox.showerror('Error', f'Error al agregar el empleado: {ex}')

    ventanaEmpleado=tk.Toplevel()
    ventanaEmpleado.title('Agregar empleado')
    
    # Título
    labelTitulo=ttk.Label(ventanaEmpleado, text='Ingresa los datos para el empleado:', font=('Helvetica', 16))
    labelTitulo.pack(padx=10, pady=10)

    # Frame para el formulario
    frameFormularioEmpleado=ttk.Frame(ventanaEmpleado)
    frameFormularioEmpleado.pack(pady=10)

    # Labels y entrys para los datos del Empleado
    nombre=tk.StringVar()
    labelNombre=ttk.Label(frameFormularioEmpleado, text='Nombre:', font=('Helvetica', 12))
    entryNombre=ttk.Entry(frameFormularioEmpleado, textvariable=nombre)
    labelNombre.pack(pady=10)
    entryNombre.pack()

    direccion=tk.StringVar()
    labelDireccion=ttk.Label(frameFormularioEmpleado, text='Dirección:', font=('Helvetica', 12))
    entryDireccion=ttk.Entry(frameFormularioEmpleado, textvariable=direccion)
    labelDireccion.pack(pady=10)
    entryDireccion.pack()

    telefono=tk.StringVar()
    labelTeléfono=ttk.Label(frameFormularioEmpleado, text='Teléfono:', font=('Helvetica', 12))
    entryTeléfono=ttk.Entry(frameFormularioEmpleado, textvariable=telefono)
    labelTeléfono.pack(pady=10)
    entryTeléfono.pack()

    fechaNac=tk.StringVar()
    labelFechaNac=ttk.Label(frameFormularioEmpleado, text='Fecha de nacimiento:', font=('Helvetica', 12))
    entryFechaNac=ttk.Entry(frameFormularioEmpleado, textvariable=fechaNac)
    labelFechaNac.pack(pady=10)
    entryFechaNac.pack()

    sexo=tk.StringVar()
    labelSexo=ttk.Label(frameFormularioEmpleado, text='Sexo:', font=('Helvetica', 12))
    entrySexo=ttk.Entry(frameFormularioEmpleado, textvariable=sexo)
    labelSexo.pack(pady=10)
    entrySexo.pack()

    sueldo=tk.DoubleVar()
    labelSueldo=ttk.Label(frameFormularioEmpleado, text='Sueldo:', font=('Helvetica', 12))
    entrySueldo=ttk.Entry(frameFormularioEmpleado, textvariable=sueldo)
    labelSueldo.pack(pady=10)
    entrySueldo.pack()

    turno=tk.StringVar()
    labelTurno=ttk.Label(frameFormularioEmpleado, text='Turno:', font=('Helvetica', 12))
    entryTurno=ttk.Entry(frameFormularioEmpleado, textvariable=turno)
    labelTurno.pack(pady=10)
    entryTurno.pack()

    contrasena=tk.StringVar()
    labelContrasena=ttk.Label(frameFormularioEmpleado, text='Contraseña:', font=('Helvetica', 12))
    entryContrasena=ttk.Entry(frameFormularioEmpleado, textvariable=contrasena)
    labelContrasena.pack(pady=10)
    entryContrasena.pack()

    # Botón para enviar el formulario
    botonAgregar=ttk.Button(frameFormularioEmpleado, text='Agregar', command=enviarPeticionBD,)
    botonAgregar.pack(pady=10)

# Función para abrir la segunda ventana
def abrir_sistema():
    global conexion

    # Conectar con la base de datos y generar un cursor para mediante el cual ejecutar comandos
    conexion=dataBase.conectarServidor().cursor()

    login_window.destroy()  # Cierra la ventana de inicio de sesión
    sistema_window = tk.Tk()
    sistema_window.title("Mi Nucleo de Diagnóstico")

    # Título
    label_titulo = ttk.Label(sistema_window, text="Mi Nucleo de Diagnóstico", font=('Helvetica', 16))
    label_titulo.pack(pady=10)

    # Menus
    menu = tk.Menu(sistema_window, tearoff=False)
    menuEmpleados = tk.Menu(menu, tearoff=False)
    menuDoctores = tk.Menu(menu, tearoff=False)
    menuPacientes = tk.Menu(menu, tearoff=False)
    menuCitas = tk.Menu(menu, tearoff=False)

    # Config MenuEmpleados
    menuEmpleados.add_command(label='Agregar empleado', command=agregarEmpleado)

    menu.add_cascade(label='Empleados', menu=menuEmpleados)
    menu.add_cascade(label='Doctores', menu=menuDoctores)
    menu.add_cascade(label='Pacientes', menu=menuPacientes)
    menu.add_cascade(label='Citas', menu=menuCitas)
    sistema_window.configure(menu=menu)

    # Imagen
    imagen = Image.open('images/salud1.png')
    imagen = ImageTk.PhotoImage(imagen)
    label_imagen = tk.Label(sistema_window, image=imagen)
    label_imagen.pack(pady=10)

    sistema_window.mainloop()

# Función para validar el inicio de sesión
def iniciar_sesion():
    usuario = entry_usuario.get()
    contrasena = entry_contrasena.get()

    if usuario == "admin" and contrasena == "1234":  # Ejemplo simple de validación
        abrir_sistema()
    else:
        messagebox.showerror("Error", "Usuario o contraseña incorrectos")

# Crear ventana de inicio de sesión
login_window = tk.Tk()
login_window.title("Inicio de sesión")
login_window.geometry("300x300")

# Título
label_titulo = ttk.Label(login_window, text="Inicio de Sesión", font=('Helvetica', 16))
label_titulo.pack(pady=10)

# Usuario
label_usuario = ttk.Label(login_window, text="Usuario:")
label_usuario.pack(pady=5)
entry_usuario = ttk.Entry(login_window)
entry_usuario.pack(pady=5)

# Contraseña
label_contrasena = ttk.Label(login_window, text="Contraseña:")
label_contrasena.pack(pady=5)
entry_contrasena = ttk.Entry(login_window, show="*")  # Mostrar '*' en lugar de texto
entry_contrasena.pack(pady=5)

# Botones
btn_aceptar = ttk.Button(login_window, text="Aceptar", command=iniciar_sesion)
btn_aceptar.pack(pady=5)

btn_cerrar = ttk.Button(login_window, text="Cerrar", command=login_window.quit)
btn_cerrar.pack(pady=5)

login_window.mainloop()

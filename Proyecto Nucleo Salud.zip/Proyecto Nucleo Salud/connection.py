'''
Equipo 5

    Moscoso Cedillo Edmundo Enrique
    Ornelas Durán Natalia Alessandra
    Paez Medrano Kevin Randú
    Quistian Arreguín Victor Daniel
    Rentería Xochipa Moisés Alejandro
'''
import psycopg2

def conectarServidor():
	try:
		connection=psycopg2.connect(
				host='localhost',
				port=5434,
				user='admin',
				password='admin',
				database='proyectoFinal')
		print('Connection succesfully')
	except Exception as ex:
		print(ex)
	return connection